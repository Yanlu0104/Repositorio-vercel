const itens = document.querySelectorAll('.results p span');
const dropzone = document.getElementById('res');
const dropzoneContainer = document.querySelector('.res-container');
const num1Display = document.querySelector('.operation p:first-child');
const operatorDisplay = document.querySelector('.operation span:nth-of-type(1)');
const num2Display = document.querySelector('.operation p:nth-child(3)');
const resetButton = document.querySelector('.button'); 

let num1, num2, total;
let correctAnswers = 0;

function gerarNovaConta() {
    dropzone.textContent = "";
    dropzoneContainer.classList.remove('correct', 'error', 'dropped');
    
    const operation = Math.floor(Math.random() * 4);

    switch (operation) {
        case 0: // Addition
            num1 = Math.floor(Math.random() * 20) + 1;
            num2 = Math.floor(Math.random() * 20) + 1;
            total = num1 + num2;
            operatorDisplay.textContent = '+';
            break;
        case 1: // Subtraction
            num1 = Math.floor(Math.random() * 20) + 1;
            num2 = Math.floor(Math.random() * num1) + 1;
            total = num1 - num2;
            operatorDisplay.textContent = '-';
            break;
        case 2: // Multiplication
            num1 = Math.floor(Math.random() * 10) + 1;
            num2 = Math.floor(Math.random() * 10) + 1;
            total = num1 * num2;
            operatorDisplay.textContent = 'x';
            break;
        case 3: // Division
            num2 = Math.floor(Math.random() * 9) + 1;
            total = Math.floor(Math.random() * 10) + 1;
            num1 = num2 * total;
            operatorDisplay.textContent = '÷';
            break;
    }

    num1Display.textContent = num1;
    num2Display.textContent = num2;

    const options = [total];
    while (options.length < 3) {
        let erro = total + (Math.random() > 0.5 ? 1 : -1) * (Math.floor(Math.random() * 2) + 1);
        if (erro >= 0 && !options.includes(erro)) {
            options.push(erro);
        }
    }

    options.sort(() => Math.random() - 0.5);

    itens.forEach((span, index) => {
        span.textContent = options[index];
    });
}

function onDragStart(e) {
    setTimeout(() => {
        e.target.classList.add('move');
    }, 0);
    e.dataTransfer.setData("text/plain", e.target.textContent);
}

function onDragEnter(e) {
    e.preventDefault();
    dropzone.classList.add('enter');
}

function onDragLeave() {
    dropzone.classList.remove('enter');
}

function onDragOver(e) {
    e.preventDefault();
}

function onDrop(e) {
    e.preventDefault();
    dropzone.classList.remove('enter');
    dropzoneContainer.classList.add('dropped');

    const value = e.dataTransfer.getData("text/plain");
    dropzone.textContent = value;

    if (total === parseInt(value)) {
        dropzoneContainer.classList.remove('error');
        dropzoneContainer.classList.add('correct');
        correctAnswers++;
        if (correctAnswers === 5) {
            setTimeout(() => {
                window.location.href = '../menu/fase_inicio.html';
            }, 1500);
        } else {
            setTimeout(gerarNovaConta, 1500); 
        }
    } else {
        dropzoneContainer.classList.remove('correct');
        dropzoneContainer.classList.add('error');
    }
}

dropzone.addEventListener('dragenter', onDragEnter);
dropzone.addEventListener('dragleave', onDragLeave);
dropzone.addEventListener('dragover', onDragOver);
dropzone.addEventListener('drop', onDrop);

itens.forEach(item => {
    item.addEventListener('dragstart', onDragStart);
    item.addEventListener('dragend', () => item.classList.remove('move'));
});

resetButton.addEventListener('click', gerarNovaConta);

gerarNovaConta();